Please use the HEX CODES to ensure maximum compatibility.

Ranik-Based Colors
Lime        (#00FF00)    other room of economic interest (bank teller, exchange, loot buyers, services, etc.)
Red         (#FF0000)    room where you can purchase an item
Yellow      (#FFFF00)    stat training room
Fuchsia     (#FF00FF)    throughpoint, portal, or transport
Aqua        (#00FFFF)    PC housing
Blue        (#0000FF)    water room (swimming required)
Navy        (#000080)    underwater room (drowning possible)
Sienna      (#993300)    mining room

Additional Colors
Sand        (#C2B280)    Ranger trailhead
Orange      (#FF8000)    guildleader
Amber       (#FFBF00)    roundtime or other non-swimming obstacle
Olive       (#808000)    Kraelyst travel script start point
Green       (#008000)    lumber room
Mint        (#00BF80)    auto-healer
Periwinkle  (#A6A3D9)    pilgrim badge shrine
Eggplant    (#400040)    depart room
Purple      (#800080)    favor altar

#goto label conventions: http://www.elanthia.org/GenieSettings/#Labels